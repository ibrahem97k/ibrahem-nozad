IBO TV - وەشانی ئامادە بۆ Firebase و Vercel

گرنگ:
ئەم فایلانە ئامادەن، بەڵام پێش بڵاوکردنەوە پێویستە Firebase Project ـی خۆت دروست بکەیت و firebase-config.js پڕ بکەیتەوە.
من ناتوانم بەبێ زانیارییەکانی Firebase ـەکەت پەیوەندی ڕاستەوخۆ دروست بکەم.

١) لە https://console.firebase.google.com بچۆ و Add project بکە.
٢) لە Project settings > General > Your apps، Web app (</>) زیاد بکە.
٣) Firebase config ـەکە کۆپی بکە و لە firebase-config.js لە شوێنی PASTE... دایبنێ.
٤) لە Authentication > Sign-in method، Email/Password چالاک بکە.
٥) لە Authentication > Users، ئیمەیڵ و وشەی نهێنی بەڕێوەبەر زیاد بکە.
٦) لە Firestore Database، Create database بکە.
٧) ناوەڕۆکی firestore.rules کۆپی بکە بۆ Firestore > Rules و Publish بکە.
٨) هەموو فایلەکانی ئەم ZIP ـە لە ڕەگی GitHub repo ـەکەت دابنێ و Commit بکە؛ Vercel پاشان Deploy دەکات.

تێبینی:
- کۆمەڵە و کەناڵەکان لە Firestore هەڵدەگیرێن و لە ئامێرە جیاوازەکان دەردەکەون.
- لینکی پەخش دەبێت ڕاستەوخۆ و گونجاو بێت؛ هەموو لینکی ماڵپەڕ لە iframe کار ناکات.
- ئەم rules ـە نووسین بۆ هەر هەژمارێکی Firebase چوونەژوورەوەکراو ڕێگەپێدەدات. هەژماری Authentication بەڕێوەبەر تەنها خۆت دروست بکە و هیچ signup ـێک بۆ خەڵک زیاد مەکە.
- Firebase web config بەخۆی وشەی نهێنی نییە؛ بەڵام وشەی نهێنی بەڕێوەبەر مەدە بە کەس.
